<template>
 <div class="col-6">
        <q-img src="..\assets\self1.jpg">
          <div class="absolute-bottom text-subtitle1 text-center">
            
          </div>
          <div class="box">
  <ul style="margin-left: 5px;margin-right: 20px;">
    <h4 style="margin-left: 20px;"><b>Nikita Kshirsagar</b></h4>
    <h6 style="margin-left: 50px;">Software Engineer</h6>

    <li>I was born and brought-up in Maharashtra.</li>
    <li>I have Mother and a Elder Brother</li>
    <br>


  </ul>
  <img style= "margin-left: 70px;"
  height="250" width="200" src="..\assets\Nikita Kshirsagar.jpg"/>

  </div>
  
 


        </q-img>
       
      </div>
    
    
</template>
<style>
.box{
margin: 0;
  position: absolute;
  top: 40%;
  left: 50%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
</style>
