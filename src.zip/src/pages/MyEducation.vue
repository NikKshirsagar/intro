<template>
    <div class="col-6">
        <q-img src="..\assets\education.jpg">
          <div class="absolute-bottom text-subtitle1 text-center">
            
          </div>
          <div class="box">
        <h5>Education Details:</h5>
  <ul>
    <li>Diploma - Government Residential Women's Polytechnic, Latur</li>
    <li>Engineering - Sinhgad Institutes, Pune</li>

  </ul>

          </div>
        </q-img>
      </div>

</template>
<style>
.box{
margin: 0;
  position: absolute;
  top: 40%;
  left:60%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
</style>