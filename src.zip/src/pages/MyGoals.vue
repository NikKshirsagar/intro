<template>

<div class="col-6">
        <q-img src="..\assets\pattern-randomized.svg">
          <div class="absolute-bottom text-subtitle1 text-center">
            Caption
          </div>
          <div class="box">
  
  <h5>Goals: </h5>
  <ul>
    <li>Be a better version of myself.</li>
    <li>Being successful in Whatever I do. </li>
    <br>
  </ul>
  
          </div>
        </q-img>
      </div>
    
</template>
<style>
.box{
margin: 0;
  position: absolute;
  top: 30%;
  left: 30%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
</style>