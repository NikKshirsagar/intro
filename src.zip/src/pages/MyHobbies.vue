<template>
        <div class="col-6">
        <q-img src="..\assets\coooking.jpg">
          <div class="absolute-bottom text-subtitle1 text-center">
            Caption
          </div>
          <div class="box">
  
    <h4> My Hobbies : </h4>
    <ul>
    <li> Gardening</li>
    <li> Cooking </li>
    <li>Binge Watching</li>
    </ul>
          </div>
        </q-img>
      </div>
    
</template>
<style>
.box{
margin: 0;
  position: absolute;
  top: 40%;
  left: 70%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
</style>